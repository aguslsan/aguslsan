package principal;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class Main {

	public static void main(String[] args) {
		
		System.out.println(TestExcepciones.testConMetodo( () -> 
			String.valueOf(4)
		));
		
		//CAMBIAR EL "2" POR UN "0" PARA VER EL MENSAJE DE ERROR
		System.out.println(TestExcepciones.testConMetodo( () -> 
			new BigDecimal("4").divide(new BigDecimal("2"), 3, RoundingMode.HALF_DOWN)
		));

	}

}
