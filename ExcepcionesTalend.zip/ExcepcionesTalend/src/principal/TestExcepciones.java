package principal;

public class TestExcepciones {
	
	public static Object testConMetodo(Lambda0Param L) {
		
		try {
			return L.miMetodo();
		} catch (Exception e) {
			throw new RuntimeException("ACA VA UN MENSAJE PERSONALIZADO",e);
		}
	}

}
