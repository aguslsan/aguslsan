package principal;

public interface Lambda0Param {

	public Object miMetodo();

}
