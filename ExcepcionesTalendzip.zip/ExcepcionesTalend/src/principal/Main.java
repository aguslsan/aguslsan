package principal;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class Main {

	public static void main(String[] args) {
		
		System.out.println(TestExcepciones.testConMetodo( () -> 
			String.valueOf(4)
		));
		
		System.out.println(TestExcepciones.testConMetodo( () -> 
			new BigDecimal("4").divide(new BigDecimal("2"), 3, RoundingMode.HALF_DOWN)
		));

	}

}
